package com.eclipse.rng.network;

import com.eclipse.rng.EclipseRngMod;
import com.eclipse.rng.mutation.Mutation;
import com.eclipse.rng.mutation.MutationCatalog;
import com.eclipse.rng.state.EclipsePlayerData;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.minecraft.server.network.ServerPlayerEntity;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

public final class EclipsePackets {
    private EclipsePackets() {}
    public record Request(int action, int mutationId) implements CustomPayload {
        public static final Id<Request> ID = new Id<>(Identifier.of(EclipseRngMod.MOD_ID,"request"));
        public static final PacketCodec<RegistryByteBuf,Request> CODEC = PacketCodec.of((v,b)->{b.writeVarInt(v.action);b.writeVarInt(v.mutationId);},b->new Request(b.readVarInt(),b.readVarInt()));
        public Id<? extends CustomPayload> getId(){return ID;}
    }
    public record Sync(int rolls,int mutationId,int unlockedCount,String message) implements CustomPayload {
        public static final Id<Sync> ID = new Id<>(Identifier.of(EclipseRngMod.MOD_ID,"sync"));
        public static final PacketCodec<RegistryByteBuf,Sync> CODEC = PacketCodec.of((v,b)->{b.writeVarInt(v.rolls);b.writeVarInt(v.mutationId);b.writeVarInt(v.unlockedCount);b.writeString(v.message,256);},b->new Sync(b.readVarInt(),b.readVarInt(),b.readVarInt(),b.readString(256)));
        public Id<? extends CustomPayload> getId(){return ID;}
    }
    public static void registerServer() {
        PayloadTypeRegistry.playC2S().register(Request.ID,Request.CODEC);
        PayloadTypeRegistry.playS2C().register(Sync.ID,Sync.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(Request.ID,(payload,context)-> context.server().execute(()->handle(context.server(),context.player(),payload)));
    }
    private static void handle(MinecraftServer server,ServerPlayerEntity player,Request request) {
        EclipsePlayerData data = EclipsePlayerData.get(server);
        EclipsePlayerData.PlayerRecord rec = data.record(player.getUuid());
        String message = "";
        if(request.action==0) {
            long now=System.currentTimeMillis();
            if(now-rec.lastRoll < 2500) message="El núcleo necesita estabilizarse...";
            else {
                Mutation found=MutationCatalog.random(); rec.mutation=found.id();rec.rolls++;rec.lastRoll=now;rec.unlocked.add(found.id());data.changed();message="Obtención: "+found.name()+" ["+found.rarity()+"]";
            }
        } else if(request.action==1) {
            Mutation chosen=MutationCatalog.byId(request.mutationId);
            if(rec.unlocked.contains(chosen.id())) {rec.mutation=chosen.id();data.changed();message="Mutación equipada: "+chosen.name();}
            else message="Todavía no descubriste esa mutación.";
        } else if(request.action==2) {
            long now=System.currentTimeMillis();
            if(rec.rolls==0) message="Primero necesitás obtener una mutación.";
            else if(now-rec.lastAbility<8000) message="La habilidad sigue en recuperación.";
            else { Mutation active=MutationCatalog.byId(rec.mutation); active.apply(player); rec.lastAbility=now; data.changed(); message="Habilidad de "+active.name()+" activada."; }
        }
        ServerPlayNetworking.send(player,new Sync(rec.rolls,rec.mutation,rec.unlocked.size(),message));
    }
}
