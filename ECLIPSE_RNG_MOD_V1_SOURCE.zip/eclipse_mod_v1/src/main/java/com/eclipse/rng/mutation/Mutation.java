package com.eclipse.rng.mutation;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.network.ServerPlayerEntity;
import java.util.List;

public record Mutation(int id, String name, String rarity, int weight, String description, List<StatusEffectInstance> effects) {
    public void apply(ServerPlayerEntity player) {
        for (StatusEffectInstance effect : effects) player.addStatusEffect(new StatusEffectInstance(effect));
    }
}
