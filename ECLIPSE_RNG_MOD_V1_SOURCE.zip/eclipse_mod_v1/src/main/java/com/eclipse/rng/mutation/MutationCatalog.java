package com.eclipse.rng.mutation;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import java.util.List;

public final class MutationCatalog {
    private MutationCatalog() {}
    public static final List<Mutation> ALL = List.of(
        new Mutation(0,"Pulso Vital","Común",32,"Recuperación natural reforzada.",List.of(new StatusEffectInstance(StatusEffects.REGENERATION,100,0))),
        new Mutation(1,"Piel de Piedra","Común",28,"Resistencia temporal al daño.",List.of(new StatusEffectInstance(StatusEffects.RESISTANCE,240,0))),
        new Mutation(2,"Paso Veloz","Poco común",18,"Movimiento acelerado.",List.of(new StatusEffectInstance(StatusEffects.SPEED,300,0))),
        new Mutation(3,"Ojo del Cazador","Poco común",16,"Mejora la percepción en combate.",List.of(new StatusEffectInstance(StatusEffects.NIGHT_VISION,600,0))),
        new Mutation(4,"Corazón Ígneo","Raro",10,"Resistencia al calor y fuego.",List.of(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE,600,0))),
        new Mutation(5,"Salto Evolutivo","Raro",9,"Mayor capacidad de salto.",List.of(new StatusEffectInstance(StatusEffects.JUMP_BOOST,300,1))),
        new Mutation(6,"Mente Acelerada","Épico",5,"Concentración y rapidez.",List.of(new StatusEffectInstance(StatusEffects.HASTE,300,0),new StatusEffectInstance(StatusEffects.SPEED,180,0))),
        new Mutation(7,"Adaptación Abisal","Épico",4,"Exploración bajo el agua.",List.of(new StatusEffectInstance(StatusEffects.WATER_BREATHING,600,0),new StatusEffectInstance(StatusEffects.NIGHT_VISION,300,0))),
        new Mutation(8,"Furia Titánica","Legendario",2,"Fuerza aumentada por tiempo limitado.",List.of(new StatusEffectInstance(StatusEffects.STRENGTH,300,1))),
        new Mutation(9,"Fase Espectral","Legendario",2,"Movimiento veloz y resistencia.",List.of(new StatusEffectInstance(StatusEffects.SPEED,300,1),new StatusEffectInstance(StatusEffects.RESISTANCE,200,0))),
        new Mutation(10,"Llama Celestial","Mítico",1,"Una energía excepcional.",List.of(new StatusEffectInstance(StatusEffects.STRENGTH,400,1),new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE,600,0))),
        new Mutation(11,"Eclipse Primordial","Eclipse",1,"Una anomalía de poder. La V1 la trata como una mutación de prueba.",List.of(new StatusEffectInstance(StatusEffects.REGENERATION,500,1),new StatusEffectInstance(StatusEffects.STRENGTH,400,2),new StatusEffectInstance(StatusEffects.RESISTANCE,400,1)))
    );
    public static Mutation byId(int id) { return ALL.stream().filter(m -> m.id() == id).findFirst().orElse(ALL.get(0)); }
    public static Mutation random() {
        int total = ALL.stream().mapToInt(Mutation::weight).sum();
        int pick = java.util.concurrent.ThreadLocalRandom.current().nextInt(total);
        for (Mutation m : ALL) { pick -= m.weight(); if (pick < 0) return m; }
        return ALL.get(0);
    }
}
