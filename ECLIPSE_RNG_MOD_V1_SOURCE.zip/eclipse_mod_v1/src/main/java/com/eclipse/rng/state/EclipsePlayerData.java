package com.eclipse.rng.state;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;
import net.minecraft.world.PersistentStateType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Server-persisted per-player prototype data (Minecraft 1.21.5+ Codec-based saved data). */
public final class EclipsePlayerData extends PersistentState {
    private final Map<UUID, PlayerRecord> records = new HashMap<>();

    private static final Codec<PlayerRecord> RECORD_CODEC = RecordCodecBuilder.create(instance -> instance.group(
        Codec.INT.optionalFieldOf("rolls", 0).forGetter(r -> r.rolls),
        Codec.INT.optionalFieldOf("mutation", 0).forGetter(r -> r.mutation),
        Codec.LONG.optionalFieldOf("lastRoll", 0L).forGetter(r -> r.lastRoll),
        Codec.LONG.optionalFieldOf("lastAbility", 0L).forGetter(r -> r.lastAbility),
        Codec.INT.listOf().optionalFieldOf("unlocked", List.of()).forGetter(r -> new ArrayList<>(r.unlocked))
    ).apply(instance, PlayerRecord::new));

    private static final Codec<EclipsePlayerData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        Codec.unboundedMap(Codec.STRING, RECORD_CODEC).optionalFieldOf("players", Map.of()).forGetter(EclipsePlayerData::exportRecords)
    ).apply(instance, EclipsePlayerData::fromRecords));

    public static final PersistentStateType<EclipsePlayerData> TYPE = new PersistentStateType<>(
        "eclipse_rng_v1",
        EclipsePlayerData::new,
        CODEC,
        null // DataFixTypes: no necesario para datos propios del mod
    );

    public static EclipsePlayerData get(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager().getOrCreate(TYPE);
    }

    public PlayerRecord record(UUID id) { return records.computeIfAbsent(id, ignored -> new PlayerRecord()); }

    public void changed() { markDirty(); }

    private Map<String, PlayerRecord> exportRecords() {
        Map<String, PlayerRecord> out = new LinkedHashMap<>();
        records.forEach((uuid, rec) -> out.put(uuid.toString(), rec));
        return out;
    }

    private static EclipsePlayerData fromRecords(Map<String, PlayerRecord> map) {
        EclipsePlayerData data = new EclipsePlayerData();
        map.forEach((key, rec) -> {
            try {
                data.records.put(UUID.fromString(key), rec);
            } catch (IllegalArgumentException ignored) {
                // clave que no es un UUID: se descarta
            }
        });
        return data;
    }

    public static final class PlayerRecord {
        public int rolls = 0, mutation = 0;
        public long lastRoll = 0, lastAbility = 0;
        public final Set<Integer> unlocked = new LinkedHashSet<>();

        public PlayerRecord() {}

        public PlayerRecord(int rolls, int mutation, long lastRoll, long lastAbility, List<Integer> unlocked) {
            this.rolls = rolls;
            this.mutation = mutation;
            this.lastRoll = lastRoll;
            this.lastAbility = lastAbility;
            this.unlocked.addAll(unlocked);
        }
    }
}
