package com.eclipse.rng.state;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.world.PersistentState;
import net.minecraft.datafixer.DataFixTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import java.util.*;

/** Server-persisted per-player prototype data. */
public final class EclipsePlayerData extends PersistentState {
    private final Map<UUID, PlayerRecord> records = new HashMap<>();
    public static final Type<EclipsePlayerData> TYPE = new Type<>(EclipsePlayerData::new, EclipsePlayerData::read, DataFixTypes.SAVED_DATA);
    public static EclipsePlayerData get(MinecraftServer server) { return server.getOverworld().getPersistentStateManager().getOrCreate(TYPE, "eclipse_rng_v1"); }
    public PlayerRecord record(UUID id) { return records.computeIfAbsent(id, ignored -> new PlayerRecord()); }
    public void changed() { markDirty(); }
    private static EclipsePlayerData read(NbtCompound nbt) {
        EclipsePlayerData data = new EclipsePlayerData();
        NbtCompound all = nbt.getCompound("players");
        for (String key : all.getKeys()) {
            try {
                UUID uuid = UUID.fromString(key); NbtCompound row = all.getCompound(key);
                PlayerRecord rec = new PlayerRecord(); rec.rolls = row.getInt("rolls"); rec.mutation = row.getInt("mutation"); rec.lastRoll = row.getLong("lastRoll"); rec.lastAbility = row.getLong("lastAbility");
                NbtList list = row.getList("unlocked", 8); for (int i=0;i<list.size();i++) rec.unlocked.add(Integer.parseInt(list.getString(i)));
                data.records.put(uuid, rec);
            } catch (Exception ignored) {}
        }
        return data;
    }
    @Override public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
        NbtCompound all = new NbtCompound();
        records.forEach((uuid, rec) -> {
            NbtCompound row = new NbtCompound(); row.putInt("rolls", rec.rolls); row.putInt("mutation", rec.mutation); row.putLong("lastRoll", rec.lastRoll); row.putLong("lastAbility", rec.lastAbility);
            NbtList list = new NbtList(); rec.unlocked.forEach(id -> list.add(NbtString.of(Integer.toString(id)))); row.put("unlocked", list); all.put(uuid.toString(), row);
        });
        nbt.put("players", all); return nbt;
    }
    public static final class PlayerRecord { public int rolls=0, mutation=0; public long lastRoll=0, lastAbility=0; public final Set<Integer> unlocked=new LinkedHashSet<>(); }
}
