package com.eclipse.rng;
import com.eclipse.rng.network.EclipsePackets;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
public class EclipseRngMod implements ModInitializer {
    public static final String MOD_ID="eclipse_rng";
    @Override public void onInitialize(){ EclipsePackets.registerServer(); }
}
