package com.eclipse.rng.client;
import com.eclipse.rng.mutation.MutationCatalog;
import com.eclipse.rng.network.EclipsePackets;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
public class EclipseMutationScreen extends Screen {
    public EclipseMutationScreen(){super(Text.literal("Mutaciones"));}
    @Override protected void init(){
        int startX=width/2-150, startY=height/2-85;
        for(int i=0;i<MutationCatalog.ALL.size();i++){
            final int id=i; var m=MutationCatalog.ALL.get(i);
            int col=i%2,row=i/2;
            addDrawableChild(ButtonWidget.builder(Text.literal(m.name()+" · "+m.rarity()),b->ClientPlayNetworking.send(new EclipsePackets.Request(1,id)))
                .dimensions(startX+col*152,startY+row*23,148,20).build());
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Volver"),b->client.setScreen(new EclipseHomeScreen())).dimensions(width/2-50,height/2+75,100,22).build());
    }
    @Override public void render(DrawContext c,int mx,int my,float d){c.fill(0,0,width,height,0xE910101B);c.drawCenteredTextWithShadow(textRenderer,"ARCHIVO DE MUTACIONES",width/2,height/2-112,0xC9A7FF);c.drawCenteredTextWithShadow(textRenderer,"Elegí una mutación descubierta para equiparla",width/2,height/2+105,0xFFBDBDBD);super.render(c,mx,my,d);}
}
