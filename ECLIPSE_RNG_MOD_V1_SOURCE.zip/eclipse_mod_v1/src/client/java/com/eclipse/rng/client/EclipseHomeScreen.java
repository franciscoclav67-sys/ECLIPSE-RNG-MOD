package com.eclipse.rng.client;
import com.eclipse.rng.network.EclipsePackets;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class EclipseHomeScreen extends Screen {
    public EclipseHomeScreen(){super(Text.literal("ECLIPSE RNG"));}
    @Override protected void init(){int cx=width/2;int y=height/2-50;
        addDrawableChild(ButtonWidget.builder(Text.literal("✦  Realizar giro"),b->ClientPlayNetworking.send(new EclipsePackets.Request(0,0))).dimensions(cx-100,y,200,24).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Mutaciones descubiertas"),b->client.setScreen(new EclipseMutationScreen())).dimensions(cx-100,y+30,200,24).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Perfil"),b->client.setScreen(new EclipseProfileScreen())).dimensions(cx-100,y+60,200,24).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Activar habilidad"),b->ClientPlayNetworking.send(new EclipsePackets.Request(2,0))).dimensions(cx-100,y+90,200,24).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Cerrar"),b->close()).dimensions(cx-100,y+120,200,24).build());
    }
    @Override public void render(DrawContext c,int mouseX,int mouseY,float delta){super.render(c,mouseX,mouseY,delta);c.drawCenteredTextWithShadow(textRenderer,"☽ ECLIPSE RNG ☾",width/2,height/2-100,0xFFC9A7FF);c.drawCenteredTextWithShadow(textRenderer,EclipseClientData.message,width/2,height/2+160,0xFFFFFFFF);}
    @Override public void renderBackground(DrawContext c,int mouseX,int mouseY,float delta){c.fill(0,0,width,height,0xE910101B);c.fill(width/2-118,height/2-115,width/2+118,height/2+155,0xFF282238);c.fill(width/2-115,height/2-112,width/2+115,height/2+152,0xFF171420);}
}
