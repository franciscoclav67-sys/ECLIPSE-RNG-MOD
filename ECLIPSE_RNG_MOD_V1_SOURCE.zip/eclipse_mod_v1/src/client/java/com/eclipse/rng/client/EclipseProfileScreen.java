package com.eclipse.rng.client;
import com.eclipse.rng.mutation.MutationCatalog;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
public class EclipseProfileScreen extends Screen {
    public EclipseProfileScreen(){super(Text.literal("Perfil de Eclipse"));}
    @Override protected void init(){addDrawableChild(ButtonWidget.builder(Text.literal("Volver"),b->client.setScreen(new EclipseHomeScreen())).dimensions(width/2-45,height/2+65,90,22).build());}
    @Override public void render(DrawContext c,int mx,int my,float d){super.render(c,mx,my,d);int x=width/2,y=height/2-65;var active=MutationCatalog.byId(EclipseClientData.mutationId);c.drawCenteredTextWithShadow(textRenderer,"PERFIL INDIVIDUAL",x,y,0xFFC9A7FF);c.drawCenteredTextWithShadow(textRenderer,"Giros realizados: "+EclipseClientData.rolls,x,y+24,0xFFFFFFFF);c.drawCenteredTextWithShadow(textRenderer,"Mutaciones descubiertas: "+EclipseClientData.unlockedCount,x,y+42,0xFFFFFFFF);c.drawCenteredTextWithShadow(textRenderer,"Mutación actual: "+active.name(),x,y+60,0xFFFFFFFF);c.drawCenteredTextWithShadow(textRenderer,"Rareza: "+active.rarity(),x,y+78,0xFFFFFFFF);}
    @Override public void renderBackground(DrawContext c,int mx,int my,float d){c.fill(0,0,width,height,0xE910101B);}
}
