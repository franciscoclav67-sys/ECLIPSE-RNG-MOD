package com.eclipse.rng.client;
public final class EclipseClientData {
    public static volatile int rolls=0, mutationId=0, unlockedCount=0;
    public static volatile String message="El Núcleo está en reposo.";
    private EclipseClientData(){}
}
