package com.eclipse.rng.client;
import com.eclipse.rng.network.EclipsePackets;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.MinecraftClient;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
public class EclipseRngClient implements ClientModInitializer {
    @Override public void onInitializeClient(){
        ClientPlayNetworking.registerGlobalReceiver(EclipsePackets.Sync.ID,(payload,context)->context.client().execute(()->{
            EclipseClientData.rolls=payload.rolls();EclipseClientData.mutationId=payload.mutationId();EclipseClientData.unlockedCount=payload.unlockedCount();EclipseClientData.message=payload.message();
        }));
        KeyBinding open=KeyBindingHelper.registerKeyBinding(new KeyBinding("key.eclipse_rng.open",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_O,"category.eclipse_rng"));
        ClientTickEvents.END_CLIENT_TICK.register(client->{while(open.wasPressed()){if(client.player!=null)client.setScreen(new EclipseHomeScreen());}});
    }
}
