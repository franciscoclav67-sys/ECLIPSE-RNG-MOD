# ECLIPSE RNG Mod — Vision V1 (prototype source)

**Target:** Minecraft Java 1.21.8 · Fabric · Java 21

This is an early source prototype intended to test the mod architecture. It is not a release-ready `.jar` yet.

## Prototype systems
- Client keybind **O** opens the ECLIPSE main screen.
- Server-authoritative weighted RNG roll (short anti-spam delay).
- 12 catalog mutations across Common → Eclipse rarities.
- Persistent player roll count, discovered mutation IDs, current mutation, and cooldown timestamps saved in overworld state.
- Equip request is validated server-side against the player's discovered mutations.
- Activate button applies the current mutation's listed vanilla status effects; server cooldown included.
- Separate home, mutation list, and player profile screens.


## Build
Requires a Java 21 JDK and Gradle 8.14+ installed.


```bash
gradle build
```

The compiled mod jar should be in `build/libs/`.


## Install for testing
1. Install Minecraft Java 1.21.8.
2. Install Fabric Loader for 1.21.8 and matching Fabric API.
3. Build this project.
4. Copy the mod jar from `build/libs/` into your Minecraft `mods` folder.
5. Launch a world, press **O**, roll, and test the screens.


## Known prototype limits
- This prototype has not been compiled or tested in a live Minecraft client in this environment.
- The mutation screen lists the prototype catalog; equip requests are checked server-side, so undiscovered mutations are rejected.
- Mutations use vanilla status effects as proof-of-concept mechanics. Unique custom mechanics, skill trees, events, item integration, and visual assets are not implemented yet.
- The current prototype does not yet have a custom registered item; the GUI opens with the **O** key.
- The code and build dependency versions are initial targets and need build verification before calling this a tested mod.

## Suggested next iteration
1. Verify compile and runtime in 1.21.8.
2. Add synchronized client-side discovery list and locked/unlocked UI states.
3. Add a custom Eclipse Core item as an alternative GUI entry.
4. Give mutations unique mechanics and add an active-skill UI/cooldown indicator.
5. Begin class, skill tree, event, and expedition modules after architecture is verified.

